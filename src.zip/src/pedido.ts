export interface Pedido {
  id: number;
  lanche: string;
  quantidade: number;
  status: 'Aceito' | 'Em preparo' | 'Pronto' | 'Em rota' | 'Entregue';
}
