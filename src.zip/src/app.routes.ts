import { Routes } from '@angular/router';
import { CadastrarPedido } from './pages/cadastrar-pedido/cadastrar-pedido';
import { ListaPedidos } from './pages/lista-pedidos/lista-pedidos';

export const routes: Routes = [
  { path: '', redirectTo: 'cadastrar', pathMatch: 'full' },
  { path: 'cadastrar', component: CadastrarPedido },
  { path: 'pedidos', component: ListaPedidos },
  { path: '**', redirectTo: 'cadastrar' }
];
