import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Pedido } from '../../pedido';
import { PedidosService } from '../services/pedidos';

@Component({
  selector: 'app-lista-pedidos',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './lista-pedidos.html',
  styleUrl: './lista-pedidos.css'
})
export class ListaPedidos {
  constructor(public pedidosService: PedidosService) {}

  get pedidos(): Pedido[] {
    return this.pedidosService.listar();
  }

  remover(id: number): void {
    this.pedidosService.remover(id);
  }

  emPreparo(id: number): void {
    this.pedidosService.pedidoEmPreparo(id);
  }

  pronto(id: number): void {
    this.pedidosService.pedidoPronto(id);
  }

  emRota(id: number): void {
    this.pedidosService.pedidoSaiuParaEntrega(id);
  }

  entregue(id: number): void {
    this.pedidosService.marcarEntregue(id);
  }
}
