import { Injectable } from '@angular/core';
import { Pedido } from '../../pedido';

@Injectable({
  providedIn: 'root'
})
export class PedidosService {
  private pedidos: Pedido[] = [];
  private proximoId = 1;

  listar(): Pedido[] {
    return this.pedidos;
  }

  adicionar(lanche: string, quantidade: number): void {
    const pedido: Pedido = {
      id: this.proximoId++,
      lanche,
      quantidade,
      status: 'Aceito'
    };

    this.pedidos.push(pedido);
  }

  remover(id: number): void {
    this.pedidos = this.pedidos.filter(pedido => pedido.id !== id);
  }

  private atualizarStatus(id: number, status: Pedido['status']): void {
    const pedido = this.pedidos.find(item => item.id === id);
    if (pedido) {
      pedido.status = status;
    }
  }

  pedidoEmPreparo(id: number): void {
    this.atualizarStatus(id, 'Em preparo');
  }

  pedidoPronto(id: number): void {
    this.atualizarStatus(id, 'Pronto');
  }

  pedidoSaiuParaEntrega(id: number): void {
    this.atualizarStatus(id, 'Em rota');
  }

  marcarEntregue(id: number): void {
    this.atualizarStatus(id, 'Entregue');
  }
}
