import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { PedidosService } from '../services/pedidos';

@Component({
  selector: 'app-cadastrar-pedido',
  standalone: true,
  imports: [FormsModule, RouterLink],
  templateUrl: './cadastrar-pedido.html',
  styleUrl: './cadastrar-pedido.css'
})
export class CadastrarPedido {
  lanche = 'X-Bacon';
  quantidade = 1;
  mensagem = '';

  lanches = [
    'X-Bacon',
    'X-Egg',
    'X-Salada',
    'X-Tudo',
    'Hot Dog',
    'Hambúrguer',
    'Batata Frita'
  ];

  constructor(private pedidosService: PedidosService) {}

  cadastrar(): void {
    if (!this.lanche || this.quantidade < 1) {
      this.mensagem = 'Escolha um lanche e uma quantidade válida.';
      return;
    }

    this.pedidosService.adicionar(this.lanche, this.quantidade);
    this.mensagem = 'Pedido cadastrado com sucesso!';
    this.lanche = 'X-Bacon';
    this.quantidade = 1;
  }
}

