import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Pedido } from '../../pedido';
import { PedidosService } from '../../services/pedidos.service';

@Component({
  selector: 'app-lista-pedidos',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './lista-pedidos.html',
  styleUrl: './lista-pedidos.css'
})
export class ListaPedidos {
  constructor(public pedidosService: PedidosService) {}

  get pedidos(): Pedido[] {
    return this.pedidosService.listar();
  }

  aceitar(id: number): void {
    this.pedidosService.pedidoEmPreparo(id);
  }

  preparar(id: number): void {
    this.pedidosService.pedidoPronto(id);
  }

  enviar(id: number): void {
    this.pedidosService.pedidoSaiuParaEntrega(id);
  }

  entregar(id: number): void {
    this.pedidosService.marcarEntregue(id);
  }

  cancelar(id: number): void {
    this.pedidosService.remover(id);
  }

  get total(): number {
    return this.pedidos.length;
  }

  get concluidos(): number {
    return this.pedidos.filter(pedido => pedido.status === 'Entregue').length;
  }

  get pendentes(): number {
    return this.pedidos.filter(pedido => pedido.status !== 'Entregue').length;
  }
}
